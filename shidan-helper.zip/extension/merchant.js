// Functions are self-contained because Chrome serializes them into the merchant tab.
export function inspectPage() {
  const main = document.querySelector("main");
  if (!main) return { ready: false };
  const labels = [...main.querySelectorAll("label")].filter((l) =>
    /\b\d{2,3}\s*cm\b/.test(l.textContent),
  );
  const sizes = labels.map((l) => {
    const input = document.getElementById(l.htmlFor);
    return {
      label: l.textContent.trim(),
      disabled: !!input?.disabled,
      selected: !!input?.checked,
    };
  });
  const text = main.innerText;
  const sku = text.match(/商品番号[：:]\s*([A-Z0-9]+)/i)?.[1] || "";
  const links = [
    ...new Map(
      [...main.querySelectorAll('a[href*="/products/"]')]
        .filter((a) => a.querySelector("img"))
        .map((a) => [
          a.href,
          {
            url: a.href,
            name: a.innerText.trim(),
            image: a.querySelector("img")?.src || "",
          },
        ]),
    ).values(),
  ];
  const color =
    [...main.querySelectorAll("h3")]
      .find((e) => e.textContent.trim().startsWith("カラー"))
      ?.textContent.trim()
      .replace(/^カラー\s*/, "") || "";
  const add = [...main.querySelectorAll("button")].find(
    (b) => b.textContent.trim() === "カートに入れる",
  );
  return {
    ready: !!(
      sizes.length ||
      links.length ||
      /アイテム|見つかりません|該当する商品/.test(text)
    ),
    url: location.href,
    title: main.querySelector("h1")?.textContent.trim() || "",
    sku,
    color,
    sizes,
    links,
    image: main.querySelector('img[src*="cdn.shopify.com"]')?.src || "",
    price: text.match(/[￥¥]\s*[\d,]+\s*\(税込\)/)?.[0] || "",
    canAdd: !!add && !add.disabled,
    selected: sizes.find((s) => s.selected)?.label || "",
  };
}
export function chooseSize(size) {
  const cm = String(size).replace(/cm/gi, "").trim();
  const labels = [...document.querySelectorAll("main label")].filter((l) =>
    new RegExp("(?:^|\\s)" + cm + "\\s*cm$").test(l.textContent.trim()),
  );
  if (labels.length !== 1)
    return { ok: false, error: "目标尺码不存在或不唯一，请人工处理" };
  const input = document.getElementById(labels[0].htmlFor);
  if (!input || input.disabled)
    return { ok: false, error: "目标尺码不可选或已缺货" };
  labels[0].click();
  return { ok: true };
}
export function addOne(expected) {
  const main = document.querySelector("main");
  if (!main) return { ok: false, error: "页面尚未加载" };
  const sku = main.innerText.match(/商品番号[：:]\s*([A-Z0-9]+)/i)?.[1] || "";
  const chosen = [...main.querySelectorAll("input[type=radio]:checked")]
    .map((r) => r.value)
    .find((v) => /cm$/.test(v));
  const add = [...main.querySelectorAll("button")].find(
    (b) => b.textContent.trim() === "カートに入れる",
  );
  if (
    location.href !== expected.url ||
    sku !== expected.sku ||
    chosen !== expected.selected
  )
    return { ok: false, error: "页面商品或尺码已变化，请重新核对" };
  if (!add || add.disabled) return { ok: false, error: "商品当前不可加购" };
  if (
    [...document.querySelectorAll("[role=dialog]")].some(
      (d) => d.getBoundingClientRect().width,
    )
  )
    return { ok: false, error: "请先关闭商家弹窗后重新核对" };
  add.click();
  return { ok: true };
}
export function additionResult() {
  const dialog = [...document.querySelectorAll("[role=dialog]")].find((d) =>
    d.innerText.includes("カートに商品が追加されました"),
  );
  if (!dialog) return { ok: false };
  const text = dialog.innerText;
  return { ok: true, text };
}
export function closeAddition() {
  const dialog = [...document.querySelectorAll("[role=dialog]")].find((d) =>
    d.innerText.includes("カートに商品が追加されました"),
  );
  const b =
    dialog &&
    [...dialog.querySelectorAll("button")].find(
      (b) => b.textContent.trim() === "お買い物を続ける",
    );
  if (b) {
    b.click();
    return true;
  }
  return false;
}
