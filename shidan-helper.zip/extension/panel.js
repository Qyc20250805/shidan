import { validateBatch, allowedProduct } from "./validation.js";
import {
  inspectPage,
  chooseSize,
  addOne,
  additionResult,
  closeAddition,
} from "./merchant.js";
const $ = (s) => document.querySelector(s);
const h = (tag, attrs = {}, ...kids) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k.startsWith("on")) n.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === "disabled") n.disabled = v;
    else n.setAttribute(k, v);
  }
  for (const c of kids.flat(Infinity))
    if (c != null)
      n.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return n;
};
const button = (t, fn, cls = "", disabled = false) =>
  h("button", { type: "button", class: cls, disabled, onClick: fn }, t);
let batch = null,
  busy = false,
  preview = null,
  merchantTab = null;
const message = (t) => {
  $("#status").textContent = t;
};
const save = () => chrome.storage.local.set({ ["batch:" + batch.id]: batch });
const run = async (fn) => {
  if (busy) return;
  busy = true;
  render();
  try {
    await navigator.locks.request(
      "shidan-merchant-operation",
      { ifAvailable: true },
      async (lock) => {
        if (!lock) throw Error("另一个助手窗口正在操作，请先完成该窗口");
        await fn();
      },
    );
  } catch (e) {
    message(e.message || "操作失败，请检查网站后重试");
  } finally {
    busy = false;
    render();
  }
};
async function script(fn, args = []) {
  const result = await chrome.scripting.executeScript({
    target: { tabId: merchantTab.id },
    func: fn,
    args,
  });
  return result[0]?.result;
}
async function navigate(url) {
  if (!/^https:\/\/www\.petit-bateau\.co\.jp\/(products\/|search\/)/.test(url))
    throw Error("目标网址不受支持");
  if (!merchantTab)
    merchantTab = await chrome.tabs.create({ url, active: false });
  else {
    try {
      merchantTab = await chrome.tabs.update(merchantTab.id, {
        url,
        active: false,
      });
    } catch {
      merchantTab = await chrome.tabs.create({ url, active: false });
    }
  }
  return waitPage();
}
async function waitPage() {
  const end = Date.now() + 25000;
  while (Date.now() < end) {
    try {
      const t = await chrome.tabs.get(merchantTab.id);
      if (t.status === "complete") {
        const view = await script(inspectPage);
        if (view.ready) return view;
      }
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  throw Error("网页加载超时或没有匹配结果，请在商家页面检查后重试");
}
async function prepare(item, url) {
  message("正在查找商品和目标尺码…");
  let view = await navigate(
    url ||
      item.url ||
      "https://www.petit-bateau.co.jp/search/" + encodeURIComponent(item.sku),
  );
  if (!view.url.includes("/products/")) {
    const links = view.links.filter((l) => allowedProduct(l.url));
    if (!links.length) throw Error("没有找到商品，请补充商品链接");
    if (links.length > 1) {
      showCandidates(item, links);
      return;
    }
    view = await navigate(links[0].url);
  }
  const chosen = await script(chooseSize, [item.size]);
  if (!chosen.ok) throw Error(chosen.error);
  let selected;
  const end = Date.now() + 8000;
  do {
    await new Promise((r) => setTimeout(r, 300));
    selected = await script(inspectPage);
  } while (Date.now() < end && (!selected.selected || !selected.canAdd));
  if (!selected.selected || !selected.canAdd)
    throw Error("目标尺码无法加购，请到网站核对库存");
  preview = { itemId: item.id, view: selected };
  showReview(item, selected);
  message("请核对两边图片、颜色和尺码，确认后才会加购。");
}
function picture(url, alt) {
  return url
    ? h("img", { src: url, alt, referrerpolicy: "no-referrer" })
    : h("p", {}, "未提供参考图片，请按货号和商品描述核对");
}
function showCandidates(item, links) {
  const p = $("#review");
  p.hidden = false;
  p.replaceChildren(
    h("h2", {}, "找到多个商品，请选择对应款式"),
    ...links.map((l) =>
      h(
        "div",
        { class: "item" },
        picture(l.image, l.name),
        h("div", {}, l.name),
        button("核对此商品", () => run(() => prepare(item, l.url))),
      ),
    ),
  );
  message("需要人工选择商品，尚未加入购物车。");
}
function showReview(item, view) {
  const p = $("#review");
  p.hidden = false;
  p.replaceChildren(
    h("h2", {}, "加购前核对"),
    h(
      "div",
      { class: "compare" },
      h(
        "div",
        {},
        h("strong", {}, "明细参考"),
        picture(item.image, item.name),
        h("p", {}, `${item.name} / ${item.color || "未填颜色"}`),
        h("p", {}, `${item.sku} / ${item.size} cm × ${item.quantity}`),
      ),
      h(
        "div",
        {},
        h("strong", {}, "网站商品"),
        picture(view.image, view.title),
        h("p", {}, view.title + " / " + view.color),
        h("p", {}, view.sku + " / " + view.selected),
        h("p", {}, view.price),
      ),
    ),
    h(
      "p",
      { class: "muted" },
      "网站货号可能包含尺码后缀。只有确认是同款同色、目标尺码正确时再加购。",
    ),
    h(
      "label",
      {},
      h("input", { id: "cart-ready", type: "checkbox" }),
      "我已核对商品，并确认购物车没有上一批残留",
    ),
    h(
      "div",
      { class: "actions" },
      button("去网站查看", () =>
        chrome.tabs.update(merchantTab.id, { active: true }),
      ),
      button(
        "确认并加入购物车",
        () => run(() => addItem(item, view)),
        "primary",
      ),
      button("取消核对", () => {
        preview = null;
        p.hidden = true;
      }),
    ),
  );
}
async function addItem(item, view) {
  if (!$("#cart-ready")?.checked) throw Error("请先勾选商品与购物车核对确认");
  const fresh = (await chrome.storage.local.get("batch:" + batch.id))[
    "batch:" + batch.id
  ];
  if (fresh) {
    batch = fresh;
    item = batch.items.find((x) => x.id === item.id);
  }
  if (
    !item ||
    item.status === "done" ||
    item.status === "adding" ||
    item.status === "uncertain"
  )
    throw Error("本商品已处理或结果待核对，禁止重复添加");
  item.status = "adding";
  await save();
  try {
    for (let i = item.added || 0; i < item.quantity; i++) {
      // Persist before each external click: a crash must never cause blind replay.
      item.status = "uncertain";
      await save();
      const result = await script(addOne, [view]);
      if (!result.ok) {
        item.status = item.added || 0 ? "uncertain" : "ready";
        await save();
        throw Error(result.error);
      }
      let ok = false;
      const end = Date.now() + 10000;
      while (Date.now() < end) {
        await new Promise((r) => setTimeout(r, 450));
        const status = await script(additionResult);
        if (status.ok) {
          if (!status.text.includes(view.selected))
            throw Error("加购反馈尺码不一致，请核对购物车");
          ok = true;
          break;
        }
      }
      if (!ok) throw Error("未收到确定加购结果，请核对购物车；不会自动重试");
      item.added = i + 1;
      await save();
      const closed = await script(closeAddition);
      if (!closed && i + 1 < item.quantity)
        throw Error("加购成功，但无法关闭提示，请人工核对后继续");
      await new Promise((r) => setTimeout(r, 500));
    }
    item.status = "done";
    await save();
    preview = null;
    $("#review").hidden = true;
    message(`已加购 ${item.quantity} 件。请在商家购物车核对并手动下单。`);
  } catch (e) {
    if (item.status !== "ready") {
      item.status = "uncertain";
      await save();
    }
    throw e;
  }
}
function render() {
  const box = $("#batch");
  $("#file").disabled = busy;
  if (!batch) return;
  box.replaceChildren(
    h(
      "h2",
      {},
      `本批 ${batch.items.reduce((n, r) => n + r.quantity, 0)} 件 · ${batch.items.filter((r) => r.status === "done").length}/${batch.items.length} 行已加购`,
    ),
    ...batch.items.map((item) =>
      h(
        "div",
        { class: "item" },
        h(
          "div",
          {},
          h("strong", {}, item.name || item.sku),
          h("small", {}, `${item.sku} · ${item.size} cm × ${item.quantity}`),
          h(
            "p",
            {},
            {
              ready: "待核对",
              adding: "正在加购",
              done: "已加购",
              uncertain: "结果待核对 · 请查看购物车",
              skipped: "已跳过",
            }[item.status] || "待核对",
          ),
        ),
        button(
          "核对商品",
          () => run(() => prepare(item)),
          "",
          busy ||
            ["done", "adding", "uncertain", "skipped"].includes(item.status),
        ),
        item.status === "uncertain"
          ? button(
              "已人工核对并补齐",
              () => {
                if (!document.getElementById("manual-" + item.id)?.checked) {
                  message("请先确认已在购物车补齐该行数量");
                  return;
                }
                run(async () => {
                  item.status = "done";
                  await save();
                  message("已记录人工核对结果");
                });
              },
              "",
              busy,
            )
          : null,
        item.status === "uncertain"
          ? h(
              "label",
              {},
              h("input", { type: "checkbox", id: "manual-" + item.id }),
              "已在网站核对款式、尺码并补齐数量",
            )
          : null,
        item.status === "ready"
          ? button(
              "跳过",
              () =>
                run(async () => {
                  item.status = "skipped";
                  await save();
                  message("已跳过，不会加购该商品");
                }),
              "",
              busy,
            )
          : null,
      ),
    ),
  );
  $("#review")
    .querySelectorAll("button")
    .forEach((b) => (b.disabled = busy));
}
$("#file").addEventListener("change", () =>
  run(async () => {
    const file = $("#file").files[0];
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) throw Error("批次文件过大");
    const raw = JSON.parse(await file.text());
    validateBatch(raw);
    const key = "batch:" + raw.id;
    const stored = (await chrome.storage.local.get(key))[key];
    if (stored) {
      const input = JSON.stringify(raw.items);
      if (stored.fingerprint !== input)
        throw Error("同一批次标识的商品内容不一致，请重新生成批次");
      batch = stored;
      batch.items.forEach((r) => {
        if (r.status === "adding") r.status = "uncertain";
      });
    } else
      batch = {
        ...raw,
        fingerprint: JSON.stringify(raw.items),
        items: raw.items.map((r) => ({ ...r, status: "ready", added: 0 })),
      };
    await save();
    $("#review").hidden = true;
    message(
      stored
        ? "已恢复此批次进度；成功商品不会重复加购。"
        : "批次已导入，请逐项核对。",
    );
  }),
);
