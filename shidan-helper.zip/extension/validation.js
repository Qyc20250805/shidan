export function allowedProduct(url) {
  try {
    const u = new URL(url);
    return (
      u.protocol === "https:" &&
      u.hostname === "www.petit-bateau.co.jp" &&
      u.pathname.startsWith("/products/")
    );
  } catch {
    return false;
  }
}
export function validateBatch(b) {
  if (
    b?.format !== "shidan-batch-v1" ||
    typeof b.id !== "string" ||
    !b.id ||
    b.id.length > 100 ||
    !Array.isArray(b.items) ||
    !b.items.length
  )
    throw Error("不是有效的加购批次");
  if (b.items.length > 20) throw Error("最多 20 行");
  let total = 0;
  const ids = new Set();
  for (const item of b.items) {
    if (typeof item.id !== "string" || ids.has(item.id))
      throw Error("商品标识重复或无效");
    ids.add(item.id);
    if (!Number.isInteger(item.quantity) || item.quantity < 1)
      throw Error("数量须为正整数");
    total += item.quantity;
    if (
      typeof item.size !== "string" ||
      !/^\d{2,3}(?:\s*cm)?$/i.test(item.size.trim())
    )
      throw Error("尺码请填写厘米数字，例如 95 或 104");
    if (
      typeof item.sku !== "string" ||
      (item.sku && !/^[a-z0-9]{4,30}$/i.test(item.sku))
    )
      throw Error("货号格式不正确");
    if (item.url && !allowedProduct(item.url))
      throw Error("只支持 Petit Bateau 日本官网商品链接");
    if (!item.sku && !item.url) throw Error("缺少货号或商品链接");
    for (const k of ["name", "color", "image"])
      if (typeof item[k] !== "string") throw Error("商品字段格式错误");
    if (
      item.image &&
      !/^https:\/\//.test(item.image) &&
      !/^data:image\/(jpeg|png|webp);base64,/.test(item.image)
    )
      throw Error("图片地址不安全");
  }
  if (total > 20) throw Error("本批数量合计超过 20 件");
  return total;
}
export function transition(item, status) {
  if (item.status === "done" && status !== "done")
    throw Error("已加购商品不可重试");
  if (item.status === "uncertain" && status === "adding")
    throw Error("请人工核对结果，不能直接重试");
  return { ...item, status };
}
